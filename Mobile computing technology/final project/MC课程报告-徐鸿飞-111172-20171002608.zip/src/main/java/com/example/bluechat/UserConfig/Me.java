package com.example.bluechat.UserConfig;

import com.example.bluechat.User;

public class Me {
    static public User m_me;
}
